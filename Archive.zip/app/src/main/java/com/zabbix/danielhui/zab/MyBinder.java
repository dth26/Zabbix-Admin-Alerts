package com.zabbix.danielhui.zab;

/**
 * Created by danielhui on 4/12/17.
 */

public class MyBinder {
}


